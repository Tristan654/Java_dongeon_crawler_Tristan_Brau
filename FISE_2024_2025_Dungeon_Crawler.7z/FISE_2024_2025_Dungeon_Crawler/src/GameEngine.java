import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameEngine implements Engine, KeyListener {
    Hero hero;



    public GameEngine(Hero hero) {
        this.hero = hero;
    }
    @Override
    public void update(){

    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_UP :
                hero.setDirection(Direction.NORTH);
                break;
            case KeyEvent.VK_DOWN:
                hero.setDirection(Direction.SOUTH);
                break;
            case KeyEvent.VK_LEFT:
                hero.setDirection(Direction.WEST);
                break;
            case KeyEvent.VK_RIGHT:
                hero.setDirection(Direction.EAST);
                break;

            case KeyEvent.VK_ESCAPE :
                if (hero.mortHero()){
                    hero.heal(100);
                    hero.x=200;
                    hero.y=300;
                }
                break;
            case KeyEvent.VK_D:
                hero.x += 150;
                break;
            case KeyEvent.VK_Q:
                hero.x -= 150;
                break;
            case KeyEvent.VK_S:
                hero.y += 150;
                break;
            case KeyEvent.VK_Z:
                hero.y -= 150;
                break;
        }
    }






    @Override
    public void keyReleased(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_UP :
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_RIGHT:
                hero.setDirection(Direction.NONE); // Direction.NONE doit être définie pour arrêter le mouvement
                break;

        }
    }



}
