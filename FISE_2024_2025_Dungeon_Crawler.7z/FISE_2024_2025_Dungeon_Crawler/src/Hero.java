import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class Hero extends DynamicSprite {
    private int maxHealth;
    private int health;
    private Image gameOverImage;
    private Direction direction;
    //private JButton buttonMort = new JButton();


    public Hero(double x, double y, Image image, double width, double height, int maxHealth, int health, Image gameOverImage) {
        super(x, y, image, width, height);
        this.maxHealth = maxHealth;
        this.health = health;
        this.gameOverImage = gameOverImage;
        if (health<=0){

        }
    }

    public void takeDamage(int damage){
        health -= damage;
        if (health<=0){
            health = 0;
        }
    }



    @Override
    public void draw(Graphics g) {
        if (health <= 0) {
            g.drawImage(gameOverImage,  650, 55, 600, 1000, null);
        } else {
            super.draw(g);
            drawHealthBar(g);
        }
    }

    // Méthode pour dessiner la barre de vie au-dessus du héros
    private void drawHealthBar(Graphics g) {
        int barWidth = (int) width; // La largeur de la barre de vie correspond à celle du sprite
        int barHeight = 5; // Hauteur de la barre de vie

        // Position de la barre de vie au-dessus du sprite
        int barX = (int) x;
        int barY = (int) y ;

        // Calcul de la largeur de la partie remplie en fonction des points de vie
        int healthWidth = (int) ((health / (double) maxHealth) * barWidth);

        // Dessin de la barre de vie : contour rouge et remplissage vert
        g.setColor(Color.RED);
        g.fillRect(barX, barY, barWidth, barHeight); // Barre rouge (fond)

        g.setColor(Color.GREEN);
        g.fillRect(barX, barY, healthWidth, barHeight); // Barre verte (points de vie actuels)

        //dessiner le contour de la barre
        g.setColor(Color.BLACK);
        g.drawRect(barX, barY, barWidth, barHeight);
    }


    public void heal(int amount) {
        health += amount;
        if (health > maxHealth) health = maxHealth;
    }

    public Boolean mortHero(){
        if (this.health <=0){
            return true;
        }
        else{
            return  false;
        }
    }

}







