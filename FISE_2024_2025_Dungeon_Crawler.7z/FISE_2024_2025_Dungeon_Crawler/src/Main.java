import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Random;

import java.util.ArrayList;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Main {

    JFrame displayZoneFrame;



    RenderEngine renderEngine;
    GameEngine gameEngine;
    PhysicEngine physicEngine;

    public Main() throws Exception{
        displayZoneFrame = new JFrame("Java Labs");
        displayZoneFrame.setSize(1920,1080);
        displayZoneFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);




        Hero hero = new Hero(200,300,
                ImageIO.read(new File("./img/heroTileSheetLowRes.png")),48,50,100,100,ImageIO.read(new File("./img/Gameover.png")));

        renderEngine = new RenderEngine(displayZoneFrame);
        physicEngine = new PhysicEngine();
        gameEngine = new GameEngine(hero);


        //chaque timer déclenche son ActionListener, ce qui signifie que chaque composant (renderEngine, gameEngine, et physicEngine) est mis à jour toutes les 50 ms.
        Timer renderTimer = new Timer(50,(time)-> renderEngine.update());
        Timer gameTimer = new Timer(50,(time)-> gameEngine.update());
        Timer physicTimer = new Timer(50,(time)-> physicEngine.update());

        renderTimer.start();
        gameTimer.start();
        physicTimer.start();





        final Image imagepieceOr = ImageIO.read(new File("./img/pieceOr.png"));

        PieceOr piece0 = new PieceOr(350,240,imagepieceOr,30,30);
        PieceOr piece1 = new PieceOr(450,1020,imagepieceOr,30,30);
        System.out.println(piece1.isActive());
//        PieceOr piece2 = new PieceOr(3503,3890,imagepieceOr,30,30);
//        PieceOr piece3 = new PieceOr(10234,7658,imagepieceOr,30,30);
//        PieceOr piece4 = new PieceOr(3765,10548,imagepieceOr,30,30);
//        PieceOr piece5 = new PieceOr(8293,15637,imagepieceOr,30,30);
//        PieceOr piece6 = new PieceOr(12987,9475,imagepieceOr,30,30);
//        PieceOr piece7 = new PieceOr(17329,14876,imagepieceOr,30,30);
//        PieceOr piece8 = new PieceOr(22930,3920,imagepieceOr,30,30);



        displayZoneFrame.getContentPane().add(renderEngine);
        displayZoneFrame.setVisible(true);

        Playground level = new Playground("./data/level1.txt");
        //SolidSprite testSprite = new DynamicSprite(100,100,test,0,0);



        renderEngine.addToRenderList(level.getSpriteList());
        renderEngine.addToRenderList(hero);
        renderEngine.addToRenderList(piece0);
        renderEngine.addToRenderList(piece1);
//        renderEngine.addToRenderList(piece2);
//        renderEngine.addToRenderList(piece3);
//        renderEngine.addToRenderList(piece4);
//        renderEngine.addToRenderList(piece5);
//        renderEngine.addToRenderList(piece6);
//        renderEngine.addToRenderList(piece7);
//        renderEngine.addToRenderList(piece8);
        physicEngine.addToMovingSpriteList(hero);
        physicEngine.setEnvironment(level.getSolidSpriteList());
        physicEngine.addToEnvironmentList(piece0);
        physicEngine.addToEnvironmentList(piece1);
//        physicEngine.addToEnvironmentList(piece2);
//        physicEngine.addToEnvironmentList(piece3);
//        physicEngine.addToEnvironmentList(piece4);
//        physicEngine.addToEnvironmentList(piece5);
//        physicEngine.addToEnvironmentList(piece6);
//        physicEngine.addToEnvironmentList(piece7);
//        physicEngine.addToEnvironmentList(piece8);


        displayZoneFrame.addKeyListener(gameEngine);


    }

    public static void main (String[] args) throws Exception {
	// write your code here
        Main main = new Main();
    }
}
