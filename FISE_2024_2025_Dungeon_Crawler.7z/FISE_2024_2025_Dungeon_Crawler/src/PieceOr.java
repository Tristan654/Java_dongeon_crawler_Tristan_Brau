import java.awt.*;
import javax.swing.*;



public class PieceOr extends SolidSprite {

    private boolean visible = true;


    public PieceOr(double x, double y, Image image, double width, double height) {
        super(x, y, image, width, height);

    }

    public boolean notVisible() {
        visible = false;
        return visible;
    }

    public boolean isActive() {
        return visible;
    }


//    public void randomPiece(PieceOr pieceOr){
//        for(int i=0 ; i<=10; i++){
//            if (!(objectBelow instanceof SolidSprite)){
//
//            }
//        }
//    }

    @Override
    public void draw(Graphics g) {
        if (visible) {
            System.out.println("Drawing piece at: " + x + ", " + y);
            g.drawImage(image, (int) x, (int) y, (int) (x + width), (int) (y + height),
                    0, 0, image.getWidth(null), image.getHeight(null), null);
        } else {
            //System.out.println("Piece not visible.");
        }
    }
}