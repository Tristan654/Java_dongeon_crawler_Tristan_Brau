import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.util.TimerTask;
import java.util.Timer;

public class Trap  extends SolidSprite{
    private final int damage =10;
    private Hero hero;
    private boolean active = true;
    private Timer timer = new Timer();

    public Trap(double x, double y, Image image, double width, double height) {
        super(x, y, image, width, height);
    }

    public boolean isActive() {
        return active;
    }

    public void désactiverTrap(){
        if (active == true) {
            active = false;

            timer.schedule(new TimerTask(){     // temps avant que le trap ce réactive 5 seconde
                @Override
                public void run(){
                    active = true;
                }
            },5000);

        }
    }



    @Override
    public void draw(Graphics g) {
        super.draw(g);
    }

}
